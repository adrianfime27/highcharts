<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @author Bennet Matschullat <hello@bennet-matschullat.com>
 * @since 07.03.2011 - 12:02:20
 * @version 1.0
 */

 
$config['template_dir'] = APPPATH.'views';
$config['cache_dir'] = APPPATH.'cache';
